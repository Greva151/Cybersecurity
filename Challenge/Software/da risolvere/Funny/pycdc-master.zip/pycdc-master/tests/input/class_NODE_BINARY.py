import Test
class MyNet(Test.t):
        pass
