async def foobar():
    pass

async def barfoo():
    await foobar()
